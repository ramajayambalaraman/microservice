package loanmanagement.accountmanagement.pojo;

public class AccountPojo {
	
	
	private String accNo;
	private int amount;
	
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	

}
