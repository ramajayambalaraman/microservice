package abcretailonline.abcregistryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcregistryserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
